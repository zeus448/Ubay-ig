# Script resmi milik: Ubay Boru Sembiring
# Logo: Boru | Bot: Ubayy | Fungsi delay: Sembiring()

import json
from instabot import Bot
from datetime import datetime
import time

# Fungsi delay custom
def Sembiring(detik):
    print(f"⏳ Tunggu {detik} detik...")
    time.sleep(detik)

# Load config
with open("config.json", "r") as f:
    cfg = json.load(f)

print("🔰 Memulai BOT Ubayy (Logo: Boru)")

Ubayy = Bot()
Ubayy.login(username=cfg["username"], password=cfg["password"])

# Logging
def log(pesan):
    with open("log.txt", "a") as f:
        waktu = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        f.write(f"[{waktu}] {pesan}\n")
    print(pesan)

# Auto-Follow
for user in cfg["targets_follow"]:
    Ubayy.follow(user)
    log(f"📌 Followed: {user}")
    Sembiring(cfg["delay_seconds"])

# Auto-Like berdasarkan hashtag
for tag in cfg["hashtags"]:
    Ubayy.like_hashtag(tag, amount=5)
    log(f"❤️ Liked posts with #{tag}")
    Sembiring(cfg["delay_seconds"])

# Auto-Comment
for tag in cfg["hashtags"]:
    media_list = Ubayy.get_hashtag_medias(tag, amount=3)
    for media in media_list:
        komentar = cfg["comments"][0]
        Ubayy.comment(media, komentar)
        log(f"💬 Commented on media {media}: '{komentar}'")
        Sembiring(cfg["delay_seconds"])

# Auto-DM
Ubayy.send_message(cfg["dm_message"], cfg["dm_users"])
log(f"📨 Sent DM to: {', '.join(cfg["dm_users"])})
Sembiring(cfg["delay_seconds"])

# Auto-Unfollow yang tidak follow back
unfollowed = 0
followers = set(Ubayy.get_user_followers(Ubayy.user_id))
following = set(Ubayy.get_user_following(Ubayy.user_id))

for user_id in following:
    if user_id not in followers:
        Ubayy.unfollow(user_id)
        log(f"❌ Unfollowed non-follower: {user_id}")
        unfollowed += 1
        Sembiring(cfg["delay_seconds"])

log(f"📉 Total Unfollowed: {unfollowed}")
log("✅ BOT Ubayy Selesai. Dijalankan dengan semangat Boru!")
